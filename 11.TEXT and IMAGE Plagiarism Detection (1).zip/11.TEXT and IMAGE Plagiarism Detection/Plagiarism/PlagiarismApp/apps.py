from django.apps import AppConfig


class PlagiarismappConfig(AppConfig):
    name = 'PlagiarismApp'
